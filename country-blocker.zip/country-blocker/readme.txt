=== Country Blocker ===
Contributors: Karl Kiesinger
Donate link: http://globalwebplugin.com/donate-page/
Tags: Country block, block traffic, IP Address,
Requires at least: 4.9
Tested up to: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
This will block any country IP that you want. It�s as easy to setup and use. 



== Description ==
This plugin "hides" Your WordPress site from traffic that is coming from any Country (you do not select).
We use a web service call https://ipstack.com this is a free service but if you have more then 10,000 requests per month you can find out the best plan for your web site. 
If you need help, go to http://globalwebplugin.com. As well if it does not work for you. Tell us please



**When a IPs Country is detected the plugin will act in one of these ways that you have pick:**

* Blank page

* Redirection

* 404 Error Page

* Default pic


== Installation ==
1. Uncompressed the file and upload the folder country blocker to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Pick the Country to not Block** page and select the Country you want to allow to your web site.

Note:

**By default USA and if you are outside the USA, the system will auto add the county you are in base on the IP address you are using.**


== 3rd Party service==
We use a web service call https://ipstack.com this is a free service but if you have more then 10,000 requests per month you can find out the best plan for your web site. 
If this plugin take off and become too much for the service, we will do it in house on are web servers.


== Frequently asked questions ==

Not yet


== Changelog ==
= 1.0 =
*First stable version
= 1.5 =
Fix a bugs in the system.
Add a database checker to make sure that is work right each time.
= 2.0 =
Rework the code for this plugin. 
Fix the 3rd Party service that was change to https://ipstack.com 
***ADD***
A blackdoor to turn off this ***plugin ONLY*** if you need to used this. You will need to type in at the end of the url ?help=yes. You need to fill in the info. Then run the it.
= 2.1 =
Fix some errors with the code. 



== Upgrade notice ==

A blackdoor to turn off this ***plugin ONLY*** if you need to used this. You will need to type in at the end of the url ?help=yes. You need to fill in the info. Then run the it.
